//
//  JournalEntry.swift
//  Trace 0.0.1v — developed by muneebwanee (https://github.com/muneebwanee)
//

import Foundation
import SwiftUI
import UniformTypeIdentifiers

public struct JournalEntry: Identifiable, Codable, Equatable {
    public var id: String // YYYY-MM-DD
    public var date: Date
    public var text: String
    public var updatedAt: Date

    public init(id: String, date: Date, text: String, updatedAt: Date = Date()) {
        self.id = id
        self.date = date
        self.text = text
        self.updatedAt = updatedAt
    }

    public var wordCount: Int {
        text.split { $0.isWhitespace || $0.isNewline }.count
    }
}

public struct TraceBackupPayload: Codable {
    public var app: String = "Trace"
    public var developer: String = "muneebwanee"
    public var version: String = "0.0.1"
    public var exportedAt: Date
    public var entries: [JournalEntry]
}

public struct TraceDocument: FileDocument {
    public static var readableContentTypes: [UTType] { [.pdf, .json, .plainText, .html] }

    public var data: Data

    public init(data: Data) {
        self.data = data
    }

    public init(configuration: ReadConfiguration) throws {
        guard let data = configuration.file.regularFileContents else {
            throw CocoaError(.fileReadCorruptFile)
        }
        self.data = data
    }

    public func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        return FileWrapper(regularFileWithContents: data)
    }
}
