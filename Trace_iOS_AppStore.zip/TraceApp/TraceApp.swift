//
//  TraceApp.swift
//  Trace — A stream of your life
//  Developed by muneebwanee
//

import SwiftUI

@main
struct TraceApp: App {
    @StateObject private var store = JournalStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
        }
    }
}
