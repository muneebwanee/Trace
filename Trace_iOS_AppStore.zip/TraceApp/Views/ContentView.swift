//
//  ContentView.swift
//  Trace 0.0.1v — developed by muneebwanee (https://github.com/muneebwanee)
//

import SwiftUI
import UniformTypeIdentifiers

public struct ContentView: View {
    @EnvironmentObject var store: JournalStore
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @State private var now = Date()
    @State private var showCalendarDrawer = false
    @State private var showSearchBar = false
    @State private var searchQuery = ""
    @State private var showSettingsSheet = false
    @State private var showFileExporter = false
    @State private var showFileImporter = false
    @State private var showFontImporter = false
    @State private var showiCloudFolderPicker = false
    @State private var exportDocument: TraceDocument? = nil
    @State private var exportContentType: UTType = .pdf
    @State private var exportFilename: String = "Trace_Diary.pdf"
    @State private var selectedDate: Date = Date()
    @State private var activeCalendarDate: Date? = nil

    private let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    public init() {}

    private var bgPaper: Color {
        store.isDarkMode
            ? Color(red: 0.086, green: 0.086, blue: 0.082)
            : Color(red: 0.96, green: 0.96, blue: 0.95)
    }

    private var textInk: Color {
        store.isDarkMode
            ? Color(red: 0.96, green: 0.96, blue: 0.95)
            : Color(red: 0.133, green: 0.133, blue: 0.125)
    }

    private var isPadLayout: Bool {
        UIDevice.current.userInterfaceIdiom == .pad || horizontalSizeClass == .regular
    }

    public var body: some View {
        ZStack {
            bgPaper.ignoresSafeArea()

            VStack(spacing: 0) {
                headerBar
                    .padding(.horizontal, isPadLayout ? 48 : 20)
                    .padding(.top, 8)
                    .padding(.bottom, 10)

                Rectangle()
                    .fill(textInk.opacity(0.12))
                    .frame(height: 1)

                if showSearchBar {
                    searchBarView
                        .padding(.horizontal, isPadLayout ? 48 : 20)
                        .padding(.vertical, 8)
                    Rectangle()
                        .fill(textInk.opacity(0.12))
                        .frame(height: 1)
                }

                ScrollViewReader { proxy in
                    VStack(spacing: 0) {
                        if showCalendarDrawer {
                            calendarDrawerView(proxy: proxy)
                                .padding(.horizontal, isPadLayout ? 48 : 20)
                                .transition(.opacity)
                        }

                        ZStack(alignment: .bottomLeading) {
                            ScrollView(.vertical, showsIndicators: false) {
                                LazyVStack(alignment: .leading, spacing: 0) {
                                    ForEach(store.timelineDates(extraSelectedDate: activeCalendarDate, searchQuery: searchQuery), id: \.self) { date in
                                        TimelineDayRow(
                                            date: date,
                                            isToday: Calendar.current.isDateInToday(date),
                                            textInk: textInk
                                        )
                                        .id(JournalStore.dateKey(for: date))
                                    }
                                }
                                .padding(.horizontal, isPadLayout ? 64 : 20)
                                .padding(.vertical, 16)
                                .frame(maxWidth: isPadLayout ? 780 : .infinity, alignment: .leading)
                                .frame(maxWidth: .infinity)
                            }

                            Button {
                                activeCalendarDate = nil
                                withAnimation(.easeInOut(duration: 0.25)) {
                                    proxy.scrollTo(JournalStore.dateKey(for: Date()), anchor: .top)
                                }
                            } label: {
                                Image(systemName: "arrow.down")
                                    .font(.system(size: 13, weight: .regular))
                                    .foregroundColor(textInk)
                                    .frame(width: 36, height: 36)
                                    .background(bgPaper)
                                    .clipShape(Circle())
                                    .overlay(
                                        Circle().stroke(textInk.opacity(0.14), lineWidth: 1)
                                    )
                            }
                            .padding(.leading, isPadLayout ? 64 : 20)
                            .padding(.bottom, 20)
                        }
                    }
                }
            }
        }
        .preferredColorScheme(store.isDarkMode ? .dark : .light)
        .onReceive(timer) { tick in
            self.now = tick
            store.syncFromWidgetIfNeeded()
        }
        .onReceive(NotificationCenter.default.publisher(for: NSUbiquitousKeyValueStore.didChangeExternallyNotification)) { _ in
            Task {
                await store.syncWithiCloud()
            }
        }
        .sheet(isPresented: $showSettingsSheet) {
            MinimalSettingsSheet(
                bgPaper: bgPaper,
                textInk: textInk,
                onExportPDF: {
                    exportDocument = TraceDocument(data: store.exportPDFData())
                    exportContentType = .pdf
                    exportFilename = "Trace_Diary.pdf"
                    showFileExporter = true
                },
                onExportJSON: {
                    exportDocument = TraceDocument(data: store.exportJSONData())
                    exportContentType = .json
                    exportFilename = "Trace_iCloud_Sync.json"
                    showFileExporter = true
                },
                onExportMarkdown: {
                    exportDocument = TraceDocument(data: store.exportMarkdownData())
                    exportContentType = .plainText
                    exportFilename = "Trace_Diary.md"
                    showFileExporter = true
                },
                onExportTXT: {
                    exportDocument = TraceDocument(data: store.exportPlainTextData())
                    exportContentType = .plainText
                    exportFilename = "Trace_Diary.txt"
                    showFileExporter = true
                },
                onImportFiles: {
                    showFileImporter = true
                },
                onUploadFont: {
                    showFontImporter = true
                },
                onLinkiCloudFolder: {
                    showiCloudFolderPicker = true
                }
            )
            .environmentObject(store)
            .presentationDetents([.medium, .large])
        }
        .fileExporter(
            isPresented: $showFileExporter,
            document: exportDocument,
            contentType: exportContentType,
            defaultFilename: exportFilename
        ) { result in
            if case .success = result {
                let fmt = DateFormatter()
                fmt.dateFormat = "HH:mm"
                store.syncStatusMessage = "Saved \(fmt.string(from: Date()))"
            }
        }
        .fileImporter(
            isPresented: $showFileImporter,
            allowedContentTypes: [.json, .plainText],
            allowsMultipleSelection: false
        ) { result in
            if case .success(let urls) = result, let url = urls.first {
                if url.startAccessingSecurityScopedResource() {
                    defer { url.stopAccessingSecurityScopedResource() }
                    let decoder = JSONDecoder()
                    decoder.dateDecodingStrategy = .iso8601
                    if let data = try? Data(contentsOf: url) {
                        if let payload = try? decoder.decode(TraceBackupPayload.self, from: data) {
                            store.mergeEntries(payload.entries)
                            store.syncStatusMessage = "Restored"
                        } else if let rawText = String(data: data, encoding: .utf8), !rawText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                            let existing = store.entryText(for: Date())
                            let combined = existing.isEmpty ? rawText : existing + "\n\n" + rawText
                            store.updateEntry(for: Date(), text: combined)
                            store.syncStatusMessage = "Imported"
                        }
                    }
                }
            }
        }
        .fileImporter(
            isPresented: $showFontImporter,
            allowedContentTypes: [.font],
            allowsMultipleSelection: false
        ) { result in
            if case .success(let urls) = result, let url = urls.first {
                store.importCustomFont(from: url)
            }
        }
        .fileImporter(
            isPresented: $showiCloudFolderPicker,
            allowedContentTypes: [.folder],
            allowsMultipleSelection: false
        ) { result in
            if case .success(let urls) = result, let folderURL = urls.first {
                store.setLinkediCloudFolder(folderURL)
            }
        }
    }

    private var headerBar: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 2) {
                Text(headerDateFormatted(now))
                    .font(.system(size: 13, weight: .regular))
                    .foregroundColor(textInk.opacity(0.48))
                Text(headerTimeFormatted(now))
                    .font(.system(size: 12, weight: .regular, design: .monospaced))
                    .foregroundColor(textInk.opacity(0.30))
            }

            Spacer()

            HStack(spacing: 16) {
                Button {
                    withAnimation(.easeInOut(duration: 0.2)) {
                        store.isDarkMode.toggle()
                    }
                } label: {
                    Image(systemName: store.isDarkMode ? "sun.max" : "moon")
                        .font(.system(size: 15, weight: .light))
                        .foregroundColor(textInk.opacity(0.55))
                }

                Button {
                    withAnimation(.easeInOut(duration: 0.2)) {
                        showSearchBar.toggle()
                        if !showSearchBar { searchQuery = "" }
                    }
                } label: {
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 15, weight: .light))
                        .foregroundColor(textInk.opacity(0.55))
                }

                Button {
                    withAnimation(.easeInOut(duration: 0.22)) {
                        showCalendarDrawer.toggle()
                    }
                } label: {
                    Image(systemName: "calendar")
                        .font(.system(size: 15, weight: .light))
                        .foregroundColor(textInk.opacity(0.55))
                }

                Button {
                    showSettingsSheet = true
                } label: {
                    Image(systemName: "line.3.horizontal")
                        .font(.system(size: 15, weight: .light))
                        .foregroundColor(textInk.opacity(0.55))
                }
            }
        }
    }

    private var searchBarView: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 12, weight: .light))
                .foregroundColor(textInk.opacity(0.45))
            TextField("Search your diary...", text: $searchQuery)
                .font(.system(size: 12))
                .foregroundColor(textInk)
            if !searchQuery.isEmpty {
                Button {
                    searchQuery = ""
                } label: {
                    Text("Clear")
                        .font(.system(size: 11))
                        .foregroundColor(textInk.opacity(0.5))
                }
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 7)
        .background(textInk.opacity(0.05))
        .cornerRadius(8)
    }

    private func calendarDrawerView(proxy: ScrollViewProxy) -> some View {
        VStack(spacing: 10) {
            DatePicker(
                "",
                selection: $selectedDate,
                displayedComponents: [.date]
            )
            .datePickerStyle(.graphical)
            .labelsHidden()
            .tint(textInk)
            .padding(.vertical, 6)
            .onChange(of: selectedDate) { newDate in
                activeCalendarDate = Calendar.current.startOfDay(for: newDate)
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.08) {
                    withAnimation(.easeInOut(duration: 0.25)) {
                        proxy.scrollTo(JournalStore.dateKey(for: newDate), anchor: .top)
                    }
                }
            }

            Rectangle()
                .fill(textInk.opacity(0.12))
                .frame(height: 1)
        }
        .background(bgPaper)
    }

    private func headerDateFormatted(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "EEE MMM d"
        return f.string(from: date)
    }

    private func headerTimeFormatted(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "HH:mm:ss"
        return f.string(from: date)
    }
}

struct TimelineDayRow: View {
    @EnvironmentObject var store: JournalStore
    let date: Date
    let isToday: Bool
    let textInk: Color
    @State private var draftText: String = ""
    @State private var unlockedFutureEditing: Bool = false
    @FocusState private var isFocused: Bool

    var isFuture: Bool {
        Calendar.current.startOfDay(for: date) > Calendar.current.startOfDay(for: Date())
    }

    var hasEntry: Bool {
        !store.entryText(for: date).trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    var body: some View {
        HStack(alignment: .top, spacing: 14) {
            HStack(alignment: .top, spacing: 8) {
                VStack(spacing: 0) {
                    nodeIndicator
                        .frame(width: 12, height: 18)
                    Rectangle()
                        .fill(textInk.opacity(0.12))
                        .frame(width: 1)
                        .frame(maxHeight: .infinity)
                }

                VStack(alignment: .leading, spacing: 1) {
                    Text(JournalStore.formattedDow(date))
                        .font(.system(size: 10, weight: isToday ? .medium : .regular))
                        .foregroundColor(isFuture && !hasEntry ? textInk.opacity(0.28) : textInk.opacity(0.55))
                    Text(JournalStore.formattedMonthDay(date))
                        .font(.system(size: 10, weight: isToday ? .medium : .regular))
                        .foregroundColor(isFuture && !hasEntry ? textInk.opacity(0.28) : textInk.opacity(0.55))
                }
                .frame(width: 38, alignment: .leading)
                .onTapGesture {
                    unlockedFutureEditing = true
                    isFocused = true
                }
            }

            // Full auto-expanding diary stream entry (NO internal scroll box, 100% of text is always visible!)
            VStack(alignment: .leading, spacing: 8) {
                if isFuture && !hasEntry && !unlockedFutureEditing {
                    Button {
                        unlockedFutureEditing = true
                        isFocused = true
                    } label: {
                        Text("(future)")
                            .font(.system(size: 12, weight: .regular))
                            .italic()
                            .foregroundColor(textInk.opacity(0.28))
                            .padding(.bottom, 24)
                    }
                    .buttonStyle(.plain)
                } else {
                    TextField(isToday ? "TODAY" : "", text: $draftText, axis: .vertical)
                        .focused($isFocused)
                        .font(.custom(store.selectedFontName, size: store.fontSize))
                        .foregroundColor(textInk)
                        .lineSpacing(5)
                        .fixedSize(horizontal: false, vertical: true)
                        .frame(maxWidth: .infinity, minHeight: isToday && draftText.isEmpty ? 120 : 32, alignment: .topLeading)
                        .contentShape(Rectangle())
                        .onTapGesture {
                            isFocused = true
                        }
                        .onChange(of: draftText) { newValue in
                            store.updateEntry(for: date, text: newValue)
                        }
                        .padding(.bottom, 26)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .onAppear {
            draftText = store.entryText(for: date)
        }
        .onChange(of: store.entries) { _ in
            let current = store.entryText(for: date)
            if current != draftText && !isFocused {
                draftText = current
            }
        }
    }

    @ViewBuilder
    private var nodeIndicator: some View {
        if isFocused {
            Image(systemName: "checkmark")
                .font(.system(size: 9, weight: .semibold))
                .foregroundColor(textInk)
        } else if hasEntry {
            Circle()
                .fill(textInk)
                .frame(width: 7, height: 7)
        } else {
            Circle()
                .stroke(textInk.opacity(0.32), lineWidth: 1)
                .frame(width: 7, height: 7)
        }
    }
}

struct MinimalSettingsSheet: View {
    @EnvironmentObject var store: JournalStore
    @Environment(\.dismiss) var dismiss

    let bgPaper: Color
    let textInk: Color
    @State private var selectedLegalTab: TraceLegalTab? = nil

    var onExportPDF: () -> Void
    var onExportJSON: () -> Void
    var onExportMarkdown: () -> Void
    var onExportTXT: () -> Void
    var onImportFiles: () -> Void
    var onUploadFont: () -> Void
    var onLinkiCloudFolder: () -> Void

    private let builtInFonts: [(label: String, postScript: String)] = [
        ("Georgia", "Georgia"),
        ("Baskerville", "Baskerville"),
        ("Palatino", "Palatino-Roman"),
        ("Sans", "HelveticaNeue"),
        ("Mono", "Courier")
    ]

    var body: some View {
        ZStack {
            bgPaper.ignoresSafeArea()

            VStack(spacing: 0) {
                HStack {
                    Text("Settings")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundColor(textInk)
                    Spacer()
                    Text("\(store.totalDaysCount)d • \(store.totalWordsCount)w")
                        .font(.system(size: 11))
                        .foregroundColor(textInk.opacity(0.45))
                        .padding(.trailing, 8)
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 13, weight: .light))
                            .foregroundColor(textInk.opacity(0.6))
                            .padding(6)
                    }
                }
                .padding(.horizontal, 22)
                .padding(.vertical, 14)

                Rectangle()
                    .fill(textInk.opacity(0.12))
                    .frame(height: 1)

                ScrollView {
                    VStack(spacing: 20) {
                        // 1. Theme (Minimalist Moon / Sun Icon)
                        HStack {
                            Label {
                                Text("Theme")
                                    .font(.system(size: 12.5))
                                    .foregroundColor(textInk)
                            } icon: {
                                Image(systemName: store.isDarkMode ? "sun.max" : "moon")
                                    .font(.system(size: 13, weight: .light))
                                    .foregroundColor(textInk.opacity(0.6))
                            }
                            Spacer()
                            Button {
                                store.isDarkMode.toggle()
                            } label: {
                                Image(systemName: store.isDarkMode ? "sun.max" : "moon")
                                    .font(.system(size: 13, weight: .light))
                                    .foregroundColor(textInk)
                                    .frame(width: 30, height: 30)
                                    .overlay(Circle().stroke(textInk.opacity(0.18), lineWidth: 1))
                            }
                        }

                        Rectangle().fill(textInk.opacity(0.12)).frame(height: 1)

                        // 2. Font Selection & Custom Font Upload
                        VStack(alignment: .leading, spacing: 12) {
                            HStack {
                                Label {
                                    Text("Font")
                                        .font(.system(size: 12.5))
                                        .foregroundColor(textInk)
                                } icon: {
                                    Image(systemName: "textformat")
                                        .font(.system(size: 13, weight: .light))
                                        .foregroundColor(textInk.opacity(0.6))
                                }
                                Spacer()
                                Button {
                                    dismiss()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { onUploadFont() }
                                } label: {
                                    HStack(spacing: 4) {
                                        Image(systemName: "plus")
                                            .font(.system(size: 10, weight: .regular))
                                        Text("Upload font")
                                            .font(.system(size: 11))
                                    }
                                    .foregroundColor(textInk.opacity(0.65))
                                }
                            }

                            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
                                ForEach(builtInFonts, id: \.postScript) { item in
                                    fontPillButton(label: item.label, fontName: item.postScript)
                                }
                                if let customPS = store.customFontPostScriptName {
                                    fontPillButton(label: "Custom", fontName: customPS)
                                }
                            }

                            HStack {
                                Text("Size")
                                    .font(.system(size: 11.5))
                                    .foregroundColor(textInk.opacity(0.6))
                                Spacer()
                                Slider(value: $store.fontSize, in: 13...22, step: 0.5)
                                    .tint(textInk)
                                    .frame(width: 140)
                            }
                        }

                        Rectangle().fill(textInk.opacity(0.12)).frame(height: 1)

                        // 3. Minimalist iCloud Sync
                        VStack(spacing: 12) {
                            HStack {
                                Label {
                                    Text("iCloud")
                                        .font(.system(size: 12.5))
                                        .foregroundColor(textInk)
                                } icon: {
                                    Image(systemName: "icloud")
                                        .font(.system(size: 13, weight: .light))
                                        .foregroundColor(textInk.opacity(0.6))
                                }
                                Spacer()
                                Text(store.iCloudAutoBackupEnabled ? store.syncStatusMessage : "Off")
                                    .font(.system(size: 11))
                                    .foregroundColor(textInk.opacity(0.55))
                                Toggle("", isOn: $store.iCloudAutoBackupEnabled)
                                    .labelsHidden()
                                    .tint(textInk)
                            }

                            HStack(spacing: 8) {
                                Button {
                                    Task { await store.backupToiCloud() }
                                } label: {
                                    Text("Sync Now")
                                        .font(.system(size: 11.5))
                                        .foregroundColor(textInk)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 7)
                                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(textInk.opacity(0.18), lineWidth: 1))
                                }

                                Button {
                                    dismiss()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { onLinkiCloudFolder() }
                                } label: {
                                    Text("iCloud Folder")
                                        .font(.system(size: 11.5))
                                        .foregroundColor(textInk)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 7)
                                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(textInk.opacity(0.18), lineWidth: 1))
                                }

                                Button {
                                    dismiss()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { onImportFiles() }
                                } label: {
                                    Text("Restore")
                                        .font(.system(size: 11.5))
                                        .foregroundColor(textInk)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 7)
                                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(textInk.opacity(0.18), lineWidth: 1))
                                }
                            }
                        }

                        Rectangle().fill(textInk.opacity(0.12)).frame(height: 1)

                        // 4. Aesthetic Diary Template & PDF / Files Export
                        VStack(alignment: .leading, spacing: 10) {
                            Label {
                                Text("Export & Files")
                                    .font(.system(size: 12.5))
                                    .foregroundColor(textInk)
                            } icon: {
                                Image(systemName: "folder")
                                    .font(.system(size: 13, weight: .light))
                                    .foregroundColor(textInk.opacity(0.6))
                            }

                            HStack(spacing: 8) {
                                Button {
                                    dismiss()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { onExportPDF() }
                                } label: {
                                    Text("Download PDF Diary")
                                        .font(.system(size: 11.5))
                                        .foregroundColor(bgPaper)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 7)
                                        .background(textInk)
                                        .cornerRadius(8)
                                }

                                Button {
                                    dismiss()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { onImportFiles() }
                                } label: {
                                    Text("Open File")
                                        .font(.system(size: 11.5))
                                        .foregroundColor(textInk)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 7)
                                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(textInk.opacity(0.18), lineWidth: 1))
                                }
                            }

                            HStack(spacing: 6) {
                                Button {
                                    dismiss()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { onExportPDF() }
                                } label: {
                                    Text("PDF")
                                        .font(.system(size: 11))
                                        .foregroundColor(textInk)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 6)
                                        .overlay(RoundedRectangle(cornerRadius: 7).stroke(textInk.opacity(0.18), lineWidth: 1))
                                }

                                Button {
                                    dismiss()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { onExportTXT() }
                                } label: {
                                    Text("Text")
                                        .font(.system(size: 11))
                                        .foregroundColor(textInk)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 6)
                                        .overlay(RoundedRectangle(cornerRadius: 7).stroke(textInk.opacity(0.18), lineWidth: 1))
                                }

                                Button {
                                    dismiss()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { onExportMarkdown() }
                                } label: {
                                    Text("Markdown")
                                        .font(.system(size: 11))
                                        .foregroundColor(textInk)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 6)
                                        .overlay(RoundedRectangle(cornerRadius: 7).stroke(textInk.opacity(0.18), lineWidth: 1))
                                }

                                Button {
                                    dismiss()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { onExportJSON() }
                                } label: {
                                    Text("Archive")
                                        .font(.system(size: 11))
                                        .foregroundColor(textInk)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 6)
                                        .overlay(RoundedRectangle(cornerRadius: 7).stroke(textInk.opacity(0.18), lineWidth: 1))
                                }
                            }
                        }

                        Rectangle().fill(textInk.opacity(0.12)).frame(height: 1)


                        // Minimalist Attribution Footer: Trace 0.0.1v & developed by muneebwanee
                        VStack(spacing: 4) {
                            Text("Trace 0.0.1v")
                                .font(.system(size: 11))
                                .foregroundColor(textInk)
                            HStack(spacing: 3) {
                                Text("developed by")
                                    .font(.system(size: 10.5))
                                    .foregroundColor(textInk.opacity(0.5))
                                Link("muneebwanee", destination: URL(string: "https://github.com/muneebwanee")!)
                                    .font(.system(size: 10.5))
                                    .foregroundColor(textInk)
                                    .underline()
                            }
                            HStack(spacing: 5) {
                                Button("Terms") { selectedLegalTab = .terms }
                                Text("•")
                                Button("Privacy") { selectedLegalTab = .privacy }
                                Text("•")
                                Button("EULA") { selectedLegalTab = .eula }
                                Text("•")
                                Button("Data Safety") { selectedLegalTab = .data }
                                Text("•")
                                Button("TNCL 1.0") { selectedLegalTab = .licenses }
                            }
                            .font(.system(size: 10))
                            .foregroundColor(textInk.opacity(0.45))
                            .padding(.top, 2)
                        }
                        .padding(.top, 10)
                    }
                    .padding(22)
                }
            }
        }
        .sheet(item: $selectedLegalTab) { initialTab in
            TraceLegalReaderView(
                initialTab: initialTab,
                bgPaper: bgPaper,
                textInk: textInk
            )
            .environmentObject(store)
        }
    }

    private func fontPillButton(label: String, fontName: String) -> some View {
        let isSelected = store.selectedFontName == fontName
        return Button {
            store.selectedFontName = fontName
        } label: {
            Text(label)
                .font(.custom(fontName, size: 11.5))
                .foregroundColor(isSelected ? bgPaper : textInk)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 7)
                .background(isSelected ? textInk : Color.clear)
                .cornerRadius(8)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(textInk.opacity(0.18), lineWidth: 1)
                )
        }
    }
}


struct TracePressScaleButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.97 : 1.0)
            .animation(.easeOut(duration: 0.13), value: configuration.isPressed)
    }
}

enum TraceLegalTab: String, CaseIterable, Identifiable {
    case terms = "Terms of Service"
    case privacy = "Privacy Policy"
    case eula = "Store EULA"
    case data = "Data & Wipe"
    case licenses = "TNCL 1.0 License"

    var id: String { rawValue }
}

struct TraceLegalReaderView: View {
    @EnvironmentObject var store: JournalStore
    @Environment(\.dismiss) var dismiss

    @State var activeTab: TraceLegalTab
    let bgPaper: Color
    let textInk: Color
    @State private var showConfirmErase: Bool = false

    init(initialTab: TraceLegalTab, bgPaper: Color, textInk: Color) {
        _activeTab = State(initialValue: initialTab)
        self.bgPaper = bgPaper
        self.textInk = textInk
    }

    var body: some View {
        ZStack {
            bgPaper.ignoresSafeArea()

            VStack(spacing: 0) {
                // Header
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(activeTab.rawValue)
                            .font(.system(size: 13, weight: .medium))
                            .foregroundColor(textInk)
                        Text("Trace 0.0.1v • TNCL 1.0 • Effective October 30, 2026")
                            .font(.system(size: 10))
                            .foregroundColor(textInk.opacity(0.45))
                    }
                    Spacer()
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 13, weight: .light))
                            .foregroundColor(textInk.opacity(0.6))
                            .padding(6)
                    }
                    .buttonStyle(TracePressScaleButtonStyle())
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 14)

                Rectangle().fill(textInk.opacity(0.12)).frame(height: 1)

                // Horizontal Minimalist Section Pills
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 6) {
                        ForEach(TraceLegalTab.allCases) { tab in
                            let isSelected = activeTab == tab
                            Button {
                                withAnimation(.spring(duration: 0.24, bounce: 0.0)) {
                                    showConfirmErase = false
                                    activeTab = tab
                                }
                            } label: {
                                Text(tab.rawValue)
                                    .font(.system(size: 10.5, weight: isSelected ? .medium : .regular))
                                    .foregroundColor(isSelected ? bgPaper : textInk)
                                    .padding(.horizontal, 11)
                                    .padding(.vertical, 5.5)
                                    .background(isSelected ? textInk : Color.clear)
                                    .clipShape(Capsule())
                                    .overlay(
                                        Capsule().stroke(textInk.opacity(0.18), lineWidth: 1)
                                    )
                            }
                            .buttonStyle(TracePressScaleButtonStyle())
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 10)
                }

                Rectangle().fill(textInk.opacity(0.12)).frame(height: 1)

                // Editorial Document Content
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        switch activeTab {
                        case .terms:
                            termsSection
                        case .privacy:
                            privacySection
                        case .eula:
                            eulaSection
                        case .data:
                            dataDeletionSection
                        case .licenses:
                            licensesSection
                        }
                    }
                    .padding(22)
                }

                Rectangle().fill(textInk.opacity(0.12)).frame(height: 1)

                HStack {
                    Text("Trace 0.0.1v • TNCL 1.0 • developed by muneebwanee")
                        .font(.system(size: 10.5))
                        .foregroundColor(textInk.opacity(0.5))
                    Spacer()
                    Button {
                        dismiss()
                    } label: {
                        Text("Done")
                            .font(.system(size: 11))
                            .foregroundColor(textInk)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 5)
                            .overlay(RoundedRectangle(cornerRadius: 7).stroke(textInk.opacity(0.18), lineWidth: 1))
                    }
                    .buttonStyle(TracePressScaleButtonStyle())
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 10)
            }
        }
    }

    private func legalBlock(title: String, bodyText: String) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title.uppercased())
                .font(.system(size: 10.5, weight: .semibold))
                .tracking(0.6)
                .foregroundColor(textInk.opacity(0.55))
            Text(bodyText)
                .font(.custom(store.selectedFontName, size: 12.5))
                .foregroundColor(textInk.opacity(0.88))
                .lineSpacing(4)
        }
    }

    private var termsSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            legalBlock(
                title: "1. Binding Agreement & Acceptance of Terms",
                bodyText: "By downloading, installing, accessing, inspecting, or using Trace (0.0.1v), developed by muneebwanee (github.com/muneebwanee/Trace), across iOS, iPadOS, macOS, Android, Windows, Linux, or Web, you agree to be bound by these Terms of Service, our Privacy Policy, our End-User License Agreement (EULA), and the Trace Non-Commercial License (TNCL) 1.0."
            )
            legalBlock(
                title: "2. 100% Offline-First Service Architecture",
                bodyText: "Trace is an ultra-minimalist, two-tone daily stream diary and mirror reflection application. It operates 100% offline-first on your device with zero user accounts, zero proprietary cloud servers, zero external CDN dependencies, and zero background telemetry."
            )
            legalBlock(
                title: "3. Complete Ownership of Your Journal Entries",
                bodyText: "You retain 100% copyright, title, moral rights, and intellectual property ownership over every word, timestamp, and exported document (PDF, Text, Markdown, JSON) you author in Trace. The developer claims zero ownership or license over your writing."
            )
            legalBlock(
                title: "4. Software Intellectual Property & TNCL 1.0 Governance",
                bodyText: "The Trace application, its source code, two-tone Warm Paper (#F5F5F3) and Soft Ink (#222220 / #161615) editorial interface, Home Screen Widgets, and documentation are owned exclusively by muneebwanee and governed by the Trace Non-Commercial License (TNCL) 1.0. You may inspect the source code, make private modifications for personal non-commercial use, and submit Pull Requests to github.com/muneebwanee/Trace, but you may NOT redistribute standalone copies, upload binaries to app stores, publish fork releases, or use Trace commercially."
            )
            legalBlock(
                title: "5. Local Data Custody & Backup Responsibility",
                bodyText: "Because Trace stores all entries locally on your device (and optional personal iCloud/Google Drive/local folders you link), muneebwanee cannot access or recover your entries if your device is lost or reset without a backup. You are solely responsible for maintaining backups via Settings."
            )
            legalBlock(
                title: "6. Custom Fonts & Home Screen Widgets",
                bodyText: "Custom font files (.ttf, .otf, .woff, .woff2) are loaded strictly on-device. Optional WidgetKit and Android AppWidget extensions display the current time, your 7-day weekly stream rhythm (S M T W T F S), aggregate stats (XD · YW), and a one-line preview of today's entry on your Home Screen."
            )
            legalBlock(
                title: "7. Disclaimer of Warranties & Limitation of Liability",
                bodyText: "TRACE IS PROVIDED ON AN 'AS IS' AND 'AS AVAILABLE' BASIS WITHOUT WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED. TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, MUNEEBWANEE SHALL NOT BE LIABLE FOR ANY INDIRECT, INCIDENTAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES, OR ANY LOSS OF DATA OR DIARY ENTRIES ($0.00 USD LIABILITY CAP)."
            )
        }
    }

    private var privacySection: some View {
        VStack(alignment: .leading, spacing: 16) {
            legalBlock(
                title: "Executive Privacy Guarantee (Zero Telemetry)",
                bodyText: "Trace collects zero personal data, runs zero analytics or advertising SDKs, makes zero outbound network requests on launch, and operates no external servers. Every word you write stays strictly on your device."
            )
            legalBlock(
                title: "1. Categories of Data We Never Collect",
                bodyText: "We never collect, log, store, transmit, or sell personal identifiers (names, emails), journal entries, IP addresses, Advertising IDs (IDFA / GAID), GPS/location data, camera/microphone/contacts data, or crash/usage analytics."
            )
            legalBlock(
                title: "2. Local On-Device Storage & App Group Sandbox",
                bodyText: "All diary entries, theme preferences, and uploaded fonts are stored locally inside your device's application sandbox. On iOS/iPadOS, today's preview snippet and 7-day dot rhythm are shared solely with TraceWidget via the local App Group container (group.com.muneebwanee.trace) on the same device."
            )
            legalBlock(
                title: "3. User-Initiated Cloud Sync & Native File Exports",
                bodyText: "Optional iCloud Sync on Apple devices uses Apple's native NSUbiquitousKeyValueStore and security-scoped iCloud Drive folders tied to your personal Apple ID. On Android, backups use Android's native Storage Access Framework linked to your personal Google Drive. The developer has zero access to your cloud accounts."
            )
            legalBlock(
                title: "4. GDPR, UK GDPR, CCPA/CPRA, India DPDP Act & COPPA",
                bodyText: "Because muneebwanee never collects or receives your personal data, you remain the sole custodian and controller of your journal. You can export your full diary or permanently erase all on-device data at any time with one tap."
            )
        }
    }

    private var eulaSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            legalBlock(
                title: "1. Grant of Personal Non-Commercial License",
                bodyText: "Subject to your continuous compliance with this EULA and the Trace Non-Commercial License (TNCL) 1.0, muneebwanee grants you a personal, revocable, non-exclusive, non-transferable, non-commercial license to install and use Trace (0.0.1v) on any compatible Apple, Android, Windows, or Linux device that you personally own or control."
            )
            legalBlock(
                title: "2. Code Inspection vs. Redistribution Restrictions",
                bodyText: "Under TNCL 1.0, developers may inspect the code, make private modifications for personal use, and submit Pull Requests to github.com/muneebwanee/Trace, but are strictly prohibited from redistributing standalone copies or binaries, uploading clones to app stores, or commercializing the software."
            )
            legalBlock(
                title: "3. Apple App Store Mandatory Terms",
                bodyText: "This EULA is concluded strictly between you and muneebwanee only, and not with Apple Inc. muneebwanee, not Apple, is solely responsible for the Licensed Application and its content. Apple has no obligation to furnish maintenance or support services and is not responsible for any product liability, legal, or intellectual property claims. Apple and Apple's subsidiaries are third-party beneficiaries of this EULA with the right to enforce it against you."
            )
            legalBlock(
                title: "4. Multi-Platform Store Compliance",
                bodyText: "Trace complies with Apple App Store Review Guidelines, Google Play Store API 36 (Android 16) Edge-to-Edge & Data Safety rules, Microsoft Store policies, and Linux repository standards."
            )
        }
    }

    private var dataDeletionSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            legalBlock(
                title: "1. Store Data Safety & Privacy Manifest Declarations",
                bodyText: "Apple App Privacy Label: Data Not Collected. Required Reason APIs (CA92.1 UserDefaults and C617.1 FileTimestamp) are declared in PrivacyInfo.xcprivacy strictly for local on-device journal storage. Google Play Data Safety: Zero data shared; zero personal data collected."
            )
            legalBlock(
                title: "2. Export Before Deleting",
                bodyText: "Before erasing local storage, you can export a full copy of your diary in Settings under Export & Files as a typeset A4 PDF Diary (Trace_Diary.pdf), Plain Text (.txt), Markdown (.md), or JSON Archive (.json)."
            )

            VStack(alignment: .leading, spacing: 10) {
                Text("ERASE ALL ON-DEVICE DIARY DATA")
                    .font(.system(size: 10.5, weight: .semibold))
                    .foregroundColor(textInk)
                Text("Permanently deletes all journal entries, custom fonts, widget previews, and preferences stored on this device. This action is immediate and irreversible.")
                    .font(.system(size: 11.5))
                    .foregroundColor(textInk.opacity(0.65))

                if !showConfirmErase {
                    Button {
                        withAnimation(.easeOut(duration: 0.16)) {
                            showConfirmErase = true
                        }
                    } label: {
                        Text("Erase All Local Diary Data")
                            .font(.system(size: 11.5, weight: .medium))
                            .foregroundColor(textInk)
                            .padding(.horizontal, 14)
                            .padding(.vertical, 8)
                            .overlay(RoundedRectangle(cornerRadius: 8).stroke(textInk.opacity(0.25), lineWidth: 1))
                    }
                    .buttonStyle(TracePressScaleButtonStyle())
                } else {
                    HStack(spacing: 8) {
                        Button {
                            store.eraseAllLocalData()
                            showConfirmErase = false
                            dismiss()
                        } label: {
                            Text("Confirm Permanent Wipe")
                                .font(.system(size: 11.5, weight: .medium))
                                .foregroundColor(bgPaper)
                                .padding(.horizontal, 14)
                                .padding(.vertical, 8)
                                .background(textInk)
                                .cornerRadius(8)
                        }
                        .buttonStyle(TracePressScaleButtonStyle())

                        Button {
                            withAnimation(.easeOut(duration: 0.16)) {
                                showConfirmErase = false
                            }
                        } label: {
                            Text("Cancel")
                                .font(.system(size: 11.5))
                                .foregroundColor(textInk)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 8)
                                .overlay(RoundedRectangle(cornerRadius: 8).stroke(textInk.opacity(0.22), lineWidth: 1))
                        }
                        .buttonStyle(TracePressScaleButtonStyle())
                    }
                }
            }
            .padding(14)
            .overlay(RoundedRectangle(cornerRadius: 12).stroke(textInk.opacity(0.16), lineWidth: 1))
        }
    }

    private var licensesSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            legalBlock(
                title: "1. Trace Non-Commercial License (TNCL) Version 1.0",
                bodyText: "Copyright (c) 2026 muneebwanee (https://github.com/muneebwanee). Official Repository: https://github.com/muneebwanee/Trace. All Rights Reserved, except as explicitly granted below.\n\nPreamble: The Trace Non-Commercial License (TNCL) 1.0 permits developers and users to inspect the source code, make private modifications for personal non-commercial use, and submit Pull Requests to the official repository, while strictly prohibiting standalone redistribution and commercial exploitation."
            )
            legalBlock(
                title: "2. Permitted Rights Under TNCL 1.0",
                bodyText: "(a) Inspect & Audit Code: View, read, and study the source code to verify its architecture and offline privacy guarantees.\n(b) Private Personal Modifications: Clone and modify the Software privately for your own personal, non-commercial use on devices you personally own or control.\n(c) Official Repository Contributions: Fork github.com/muneebwanee/Trace solely to develop, test, and submit Pull Requests back to the official repository."
            )
            legalBlock(
                title: "3. Strict Restrictions Under TNCL 1.0",
                bodyText: "Without prior written permission from muneebwanee, you may NOT: (a) redistribute, publish, mirror, or share standalone copies, modified forks, or compiled binaries (.apk, .aab, .ipa, .appx, .msix, .exe, .AppImage, .deb); (b) upload Trace or modified clones to any app store or package registry; (c) publish GitHub Releases from a fork; (d) use the Software for any commercial purpose; or (e) remove 'Trace 0.0.1v' or 'developed by muneebwanee' attributions."
            )
            legalBlock(
                title: "4. Contributor License Grant & Credits",
                bodyText: "Any contribution submitted via Pull Request to github.com/muneebwanee/Trace grants muneebwanee a perpetual, worldwide, irrevocable, royalty-free license to include, distribute, and relicense the contribution as part of Trace. Editorial fonts (Newsreader, EB Garamond, Lora, Inter, Courier Prime) are licensed under the SIL Open Font License 1.1. UI motion principles informed by emilkowalski/skills."
            )
        }
    }
}
