// swift-tools-version: 5.8
import PackageDescription

let package = Package(
    name: "Trace",
    platforms: [
        .iOS(.v16)
    ],
    products: [
        .library(name: "Trace", targets: ["Trace"])
    ],
    targets: [
        .target(
            name: "Trace",
            path: "TraceApp"
        )
    ]
)
