# Store Compliance, Data Safety & Regulatory Declarations (`2026 Edition`)

- **Apple App Store Connect:** `ITSAppUsesNonExemptEncryption = false`, `NSPrivacyTracking = false`, `CA92.1`, `C617.1`, `TraceWidgetExtension` (`com.muneebwanee.trace.widget`), Age Rating `4+`.
- **Google Play Console:** `compileSdk 36`, `targetSdk 36`, `minSdk 24`, 16 KB Memory Page Size aligned (`packaging.jniLibs.useLegacyPackaging = false`), Data Safety: Zero data collected or shared.
- **Microsoft Partner Center:** Windows 10/11 `.appx` / `.msix` with SHA2-256 blockmap + `.exe` NSIS installer (`outputDirectory: "release-builds"`).
- **Linux Flathub & Snapcraft:** `io.github.muneebwanee.Trace`, AppStream 1.0+ `metainfo.xml` with `oars-1.1` content rating.
