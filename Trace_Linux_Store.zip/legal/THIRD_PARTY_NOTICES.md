# Third-Party Notices & Credits — Trace (`0.0.1v`)

**Trace (`0.0.1v`)** is developed by **[muneebwanee](https://github.com/muneebwanee)** and licensed under the **Trace Non-Commercial License (TNCL) 1.0** (`https://github.com/muneebwanee/Trace`).

## 1. Application License
- **Trace (`0.0.1v`)**: Copyright (c) 2026 muneebwanee. Licensed under the **Trace Non-Commercial License (TNCL) 1.0**.

## 2. Design Engineering & Motion Inspiration
- **UI & Animation Principles**: Informed by Emil Kowalski's open design-engineering skills (`https://github.com/emilkowalski/skills` — `emil-design-eng`, `mobile-native`, `apple-design`, and `review-animations`).

## 3. Typography & System Runtimes
- **Editorial Typefaces**: Newsreader, EB Garamond, Lora, Inter, and Courier Prime (SIL Open Font License 1.1).
- **Android Platform**: Android SDK 36 & WebKit (Apache License 2.0).
- **Apple Platform**: SwiftUI, WidgetKit & UIKit (Apple SDK License).
- **Windows & Linux Packaging**: Electron & electron-builder (MIT License — applies strictly to the underlying Electron runtime binary, while Trace's application code and assets remain governed by TNCL 1.0).
