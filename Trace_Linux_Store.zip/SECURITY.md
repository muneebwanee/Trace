# Security Policy for Trace (`0.0.1v`)

Trace stores all data locally on your device or inside your user-authorized iCloud Drive / Google Drive folder. Report any security issues at [https://github.com/muneebwanee/Trace/issues](https://github.com/muneebwanee/Trace/issues).
